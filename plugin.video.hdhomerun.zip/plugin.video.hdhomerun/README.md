# HDHomeRun Video Plugin

![hdhomerun](icon.png)

A Kodi plugin that will auto-discover and play TV content from a HDHomeRun box.

### Device Listing

![screenshot-01](resources/screenshot-01.png)

### Channel Listing

![screenshot-02](resources/screenshot-02.png)
